function test3() {
    if(document.getElementById("webkit-h1").style.color == "lightblue") {
        document.getElementById("webkit-h1").style.color = "red";
    } else {
        document.getElementById("webkit-h1").style.color = "lightblue";
    }
}
